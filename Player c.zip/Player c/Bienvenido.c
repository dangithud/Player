#include <stdio.h>
#include <stdbool.h>
#include "maze.h"
#include "player.h"

void juegoNuevo() {
    int playerX = 0;
    int playerY = 0;
    int movimientos = 0;

    printf("¡Bienvenido al juego de laberinto!\n");
    printf("El objetivo del juego es llegar a la esquina inferior derecha del laberinto.\n");
    printf("Usa las teclas WASD para moverte (W: arriba, S: abajo, A: izquierda, D: derecha).\n");

    while (true) {
        printf("\n=== Menú ===\n");
        printf("1. Imprimir laberinto\n");
        printf("2. Mover jugador\n");
        printf("3. Salir\n");
        printf("Ingrese su opción: ");

        int choice;
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Laberinto:\n");
                printMaze();
                break;
            case 2:
                printf("Posición del jugador: (%d, %d)\n", playerX, playerY);
                printf("Selecciona tu movimiento: ");
                char move;
                scanf(" %c", &move);

                switch (move) {
                    case 'W':
                    case 'w':
                        if (isValidMove(playerX - 1, playerY)) {
                            playerX -= 1;
                            movimientos++;
                        } else {
                            printf("Movimiento inválido. No puedes moverte hacia arriba.\n");
                        }
                        break;
                    case 'S':
                    case 's':
                        if (isValidMove(playerX + 1, playerY)) {
                            playerX += 1;
                            movimientos++;
                        } else {
                            printf("Movimiento inválido. No puedes moverte hacia abajo.\n");
                        }
                        break;
                    case 'A':
                    case 'a':
                        if (isValidMove(playerX, playerY - 1)) {
                            playerY -= 1;
                            movimientos++;
                        } else {
                            printf("Movimiento inválido. No puedes moverte hacia la izquierda.\n");
                        }
                        break;
                    case 'D':
                    case 'd':
                        if (isValidMove(playerX, playerY + 1)) {
                            playerY += 1;
                            movimientos++;
                        } else {
                            printf("Movimiento inválido. No puedes moverte hacia la derecha.\n");
                        }
                        break;
                    default:
                        printf("Movimiento inválido. Por favor, seleccione un movimiento válido.\n");
                        continue;
                }

                if (hasWon(playerX, playerY)) {
                    printf("¡Felicidades, has llegado a la esquina inferior derecha!\n");
                    printf("Número de movimientos: %d\n", movimientos);

                    if (movimientos <= 8) {
                        printf("¡Eres un Pro!\n");
                    } else if (movimientos <= 15) {
                        printf("Eres un novato.\n");
                    } else {
                        printf("Eres un noob.\n");
                    }

                    return;
                }

                break;
            case 3:
                printf("¡Hasta luego!\n");
                return;
            default:
                printf("Opción inválida. Por favor, seleccione una opción válida.\n");
                break;
        }
    }
}

int main() {
    juegoNuevo();
    return 0;
}

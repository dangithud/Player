#include <stdio.h>
#include "maze.h"
#include "player.h"

void juegoNuevo() {
    printf("¡Bienvenido al juego del laberinto!\n");
    printf("Instrucciones:\n");
    printf("Utiliza las teclas WASD para moverte por el laberinto.\n");
    printf("El objetivo es llegar a la esquina inferior derecha del laberinto.\n");
    printf("--------------------------------------------------------------\n");

    printMaze(); // Imprimir el laberinto inicial

    while (!checkWin()) {
        char direction;
        printf("Ingresa una dirección (WASD): ");
        scanf(" %c", &direction);
        movePlayer(direction);
        printMaze(); // Imprimir el laberinto después de cada movimiento
    }

    printf("¡Ganaste!\n");
    printResult();
}

int main() {
    int opcion;

    do {
        printf("----- MENÚ PRINCIPAL -----\n");
        printf("1. Juego Nuevo\n");
        printf("0. Salir\n");
        printf("Ingrese una opción: ");
        scanf("%d", &opcion);

        switch (opcion) {
            case 1:
                juegoNuevo();
                break;
            case 0:
                printf("¡Gracias por jugar!\n");
                break;
            default:
                printf("Opción inválida. Por favor, selecciona una opción válida.\n");
                break;
        }

        printf("----------------------------\n");
    } while (opcion != 0);

    return 0;
}

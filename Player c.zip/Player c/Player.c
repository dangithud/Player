#include "player.h"

int playerX = 0;
int playerY = 0;
int moves = 0;

void movePlayer(char direction) {
    int newX = playerX;
    int newY = playerY;

    switch (direction) {
        case 'W':
            newX--;
            break;
        case 'S':
            newX++;
            break;
        case 'A':
            newY--;
            break;
        case 'D':
            newY++;
            break;
        default:
            printf("Movimiento inválido: Dirección no válida.\n");
            return;
    }

    if (isValidMove(newX, newY)) {
        playerX = newX;
        playerY = newY;
        moves++;
        printf("Movimiento válido: Nueva posición del jugador: (%d, %d)\n", playerX, playerY);
    }
}

bool checkWin() {
    if (playerX == ROWS - 1 && playerY == COLS - 1) {
        return true;
    }
    return false;
}

void printResult() {
    if (moves <= 8) {
        printf("¡Eres un Pro!\n");
    } else if (moves <= 15) {
        printf("Eres novato.\n");
    } else {
        printf("Eres un noob!\n");
    }
}
